import Matematika
jari_jari = float(input("Masukkan jari-jari lingkaran: "))
luas_lingkaran = Matematika.lingkaran(jari_jari)
print("Luas lingkaran anda adalah", luas_lingkaran)

sisi = float(input("Masukkan sisi persegi: "))

luas_persegi = Matematika.luas_persegi(sisi)
print("Luas persegi anda adalah", luas_persegi)