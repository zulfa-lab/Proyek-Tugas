import Matematika

try:
    
    r = input("Masukkan jari-jari lingkaran: ")
    if r == "":
        raise ValueError
    if not r.replace('.', '', 1).isdigit():  
        raise TypeError
    r = float(r) 
    
    luas_lingkaran = Matematika.lingkaran(r)
    print("Luas lingkaran anda adalah", luas_lingkaran)

    s = input("Masukkan sisi persegi: ")
    if s == "":
        raise ValueError
    if not s.replace('.', '', 1).isdigit():  
        raise TypeError
    s = float(s)  
    
    luas_persegi = Matematika.luas_persegi(s)
    print("Luas persegi anda adalah", luas_persegi)

except ValueError:
    print("Input tidak boleh kosong")
except TypeError:
    print("Hanya boleh memasukkan angka")

