import Matematika

try:
    r = input("Masukkan jari-jari lingkaran: ")
    if r == "":
        raise ValueError("Input tidak boleh kosong.")
    luas_lingkaran = Matematika.lingkaran(r)
    print("Luas lingkaran anda adalah", luas_lingkaran)
    s = input("Masukkan sisi persegi: ")
    if s == "":
        raise ValueError("Input tidak boleh kosong.")
    s = float(s)
    luas_persegi = Matematika.luas_persegi(s)
    print("Luas persegi anda adalah", luas_persegi)
except ValueError:
    print("Tidak boleh kosong")
except Exception:
    print("Hanya boleh memasukkan angka")
