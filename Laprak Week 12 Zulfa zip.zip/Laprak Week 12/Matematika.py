def lingkaran(jari_jari):
    pi = 3.14159
    return pi * jari_jari ** 2

def luas_persegi(sisi):
    return sisi**2